-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema java_proj
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `java_proj` ;

-- -----------------------------------------------------
-- Schema java_proj
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `java_proj` DEFAULT CHARACTER SET utf8 ;
SHOW WARNINGS;
USE `java_proj` ;

-- -----------------------------------------------------
-- Table `chercheur`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `chercheur` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `chercheur` (
  `CIN_ch` INT NOT NULL,
  `Prenom_ch` VARCHAR(45) NOT NULL,
  `Nom_ch` VARCHAR(45) NOT NULL,
  `Etablis` TINYINT NOT NULL,
  `mot_de_passe` VARCHAR(200) NOT NULL,
  `TH_nom` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`CIN_ch`))
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE UNIQUE INDEX `CIN_ch_UNIQUE` ON `chercheur` (`CIN_ch` ASC) VISIBLE;

SHOW WARNINGS;
CREATE UNIQUE INDEX `mot_de_passe_UNIQUE` ON `chercheur` (`mot_de_passe` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `Article`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Article` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `Article` (
  `ID_art` INT NOT NULL,
  `Score` FLOAT NOT NULL,
  `Titre` VARCHAR(45) NOT NULL,
  `TH_nom` VARCHAR(45) NOT NULL,
  `cont` INT NULL,
  `session_id` INT NULL,
  `pdf` LONGBLOB NULL,
  PRIMARY KEY (`ID_art`))
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE UNIQUE INDEX `ID_art_UNIQUE` ON `Article` (`ID_art` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `Tutorial`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Tutorial` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `Tutorial` (
  `ID_tuto` INT NOT NULL,
  `ch_ID` INT NOT NULL,
  `TH_nom` VARCHAR(45) NOT NULL,
  `jour_Date` DATE NOT NULL,
  `Nom` VARCHAR(45) NOT NULL,
  `date` VARCHAR(10) NOT NULL,
  `site` VARCHAR(255) NULL,
  PRIMARY KEY (`ID_tuto`, `ch_ID`, `TH_nom`))
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE UNIQUE INDEX `ID_tuto_UNIQUE` ON `Tutorial` (`ID_tuto` ASC) VISIBLE;

SHOW WARNINGS;
CREATE UNIQUE INDEX `jour_Date_UNIQUE` ON `Tutorial` (`jour_Date` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `paricipant`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `paricipant` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `paricipant` (
  `CIN_Part` INT NOT NULL,
  `nom_Part` VARCHAR(45) NOT NULL,
  `prenom_Part` VARCHAR(45) NOT NULL,
  `mot_de_passe` VARCHAR(45) NOT NULL,
  `Numéro` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`CIN_Part`))
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE UNIQUE INDEX `CIN_Part_UNIQUE` ON `paricipant` (`CIN_Part` ASC) VISIBLE;

SHOW WARNINGS;
CREATE UNIQUE INDEX `mot_de_passe_UNIQUE` ON `paricipant` (`mot_de_passe` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `session`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `session` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `session` (
  `id_session` INT NOT NULL AUTO_INCREMENT,
  `jour_Date` DATE NOT NULL,
  `théme` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_session`, `jour_Date`))
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `evaluer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `evaluer` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `evaluer` (
  `ID_ch` INT NOT NULL,
  `art_ID` INT NOT NULL,
  `Note` INT NOT NULL,
  PRIMARY KEY (`ID_ch`, `art_ID`))
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `Rediger`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Rediger` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `Rediger` (
  `ID_ch` INT NOT NULL,
  `art_ID` INT NOT NULL,
  `Titre` VARCHAR(45) NOT NULL,
  `nom` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ID_ch`, `art_ID`))
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `assister`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assister` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `assister` (
  `TUTO_id` INT UNSIGNED NOT NULL,
  `TUTO_CH_nom` INT NULL,
  `PAR_cin` INT NOT NULL,
  `CO_nom` VARCHAR(45) NULL,
  PRIMARY KEY (`TUTO_id`, `PAR_cin`))
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `apr`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `apr` ;

SHOW WARNINGS;
CREATE TABLE IF NOT EXISTS `apr` (
  `ID_art` INT NOT NULL,
  `id_session` INT NOT NULL,
  `Score` FLOAT NOT NULL,
  `Titer` VARCHAR(45) NOT NULL,
  `session_jour_Date` DATE NULL,
  PRIMARY KEY (`ID_art`, `id_session`))
ENGINE = InnoDB;

SHOW WARNINGS;
USE `java_proj` ;

-- -----------------------------------------------------
-- View `view1`
-- -----------------------------------------------------
DROP VIEW IF EXISTS `view1` ;
SHOW WARNINGS;
USE `java_proj`;

SHOW WARNINGS;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
